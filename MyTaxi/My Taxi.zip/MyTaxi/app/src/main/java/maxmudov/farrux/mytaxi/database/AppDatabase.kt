package maxmudov.farrux.mytaxi.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import maxmudov.farrux.mytaxi.data.remote.dto.ModelData

@Database(entities = [ModelData::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun inputDao(): InputDao

    companion object {
        private var INSTANCE: AppDatabase? = null

        fun initDataBase(contex: Context): AppDatabase {
            return INSTANCE ?: Room.databaseBuilder(
                contex.applicationContext,
                AppDatabase::class.java,
                "My_Taxi_Database"
            ).build()
        }


    }

}