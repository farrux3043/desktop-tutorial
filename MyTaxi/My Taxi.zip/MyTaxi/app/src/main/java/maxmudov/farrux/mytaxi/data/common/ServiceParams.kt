package maxmudov.farrux.mytaxi.data.common

object ServiceParams {
    const val LOGIN = "login"
    const val TASK_LIST = "task/today"
    const val UPLOAD = "upload"
    const val USER = "user/myself"
    const val TASK = "task"
    const val TYPE = "type"
    const val COMMENT="comment"
}