package maxmudov.farrux.mytaxi.data.remote

interface MainApiService {
    

}