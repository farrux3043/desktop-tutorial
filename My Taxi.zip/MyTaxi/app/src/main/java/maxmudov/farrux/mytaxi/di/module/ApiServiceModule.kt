package maxmudov.farrux.mytaxi.di.module

import dagger.Module
import dagger.Provides
import retrofit2.Retrofit
import maxmudov.farrux.mytaxi.data.remote.MainApiService
import javax.inject.Singleton

@Module
class ApiServiceModule {

//    @Singleton
//    @Provides
//    fun provideMainService(retrofit: Retrofit): MainApiService =
//        retrofit.create(MainApiService::class.java)


}